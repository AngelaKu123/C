#include "apue.h"
#include <sys/wait.h>

static void	sig_int(int);		/* our signal-catching function */
int main(void)
{
	char	buf[MAXLINE];	/* from apue.h */
	pid_t	pid;
	int		status;

	if (signal(SIGINT, sig_int) == SIG_ERR)
			err_sys("signal error");

	printf("## ");	/* print prompt (printf requires %% to print %) */
	while (fgets(buf, MAXLINE, stdin) != NULL) {
		if (buf[strlen(buf) - 1] == '\n')
			buf[strlen(buf) - 1] = 0; /* replace newline with null */

		char *args[MAXLINE]; /* 定義一個字符串數組來存放命令和參數 */
        char *token = strtok(buf, " "); /* 使用空格分割命令和參數 */
        int i = 0;
        while (token != NULL) {
            args[i++] = token;
            token = strtok(NULL, " ");
        }
        args[i] = NULL; /* 最後一個參數為NULL，標誌參數結束 */

		if (strncmp(args[0], "cd", 2) == 0) {
            // 如果輸入的是 "cd 目錄"，則解析目錄路徑並執行 chdir
            char *directory = buf + 3; // 跳過 "cd " 部分
            chdir(args[1]);
			printf("## ");
            continue;
        }

		if ((pid = fork()) < 0) {
			err_sys("fork error");
			} 
		else if (pid == 0) {		/* child */
			execvp(args[0], args);
			err_ret("couldn't execute: %s", buf);
			exit(127);
			}

		/* parent */
		if ((pid = waitpid(pid, &status, 0)) < 0)
			err_sys("waitpid error");
		
		printf("## ");
		}
		exit(0);
}

void sig_int(int signo)
{
	printf("interrupt\n## ");
}